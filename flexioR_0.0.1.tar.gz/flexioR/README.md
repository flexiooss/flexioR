# flexioR
> R library to manipulate Flexio API

## Functionalities
* Get ressources from Flexio as data frames



## Installation
> If you need stable version, use ``ref="master"`` instead of ``ref="develop"``
```bash
devtools::install_github("flexiooss/flexioR", ref="develop")
```

## Test installation
```
library(flexioR)
helloworld()
```
