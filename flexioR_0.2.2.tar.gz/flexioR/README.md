# flexioR  
> R library to manipulate Flexio API

## Functionalities  
* Interacts with Flexio's resource API

## Installation  
> If you need unstable developement version, use ``ref="develop"`` instead of ``ref="master"``
```bash
devtools::install_github("flexiooss/flexioR", ref="master")
```
## Ressources  
> [Documentation](https://rawgit.com/flexiooss/flexioR/master/docs/index.html)
