# flexioR
R library to manipulate Flexio API

## Functionalities
* Get ressources from Flexio as data frames
